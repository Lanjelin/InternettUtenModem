GP2 Setups

All setups in one file!

Just go to DRIVE MENU, then DRIVE OPTIONS,
then CAR SETUPS MENU. Hit LOAD ALL TRACKS and pick "WHEPED.TSU".
All Wheel-Pedal setups are now loaded.

By:

Gesualdo Carlotta
carlotta@axionet.com