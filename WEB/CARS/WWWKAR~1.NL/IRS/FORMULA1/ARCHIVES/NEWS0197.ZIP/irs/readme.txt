International Racing Site News - January 1997
Most detailed and up-to-date F1 Web Site

All articles are copyright to their source. Distribution of this
file is allowed when no fee is charged. The Zip file must contain
this readme text.


Unzip the file on your local drive and the files will be unpacked
into <drive>:\irs\. Start newssumm.htm in your favourit browser and
click on an article to read it.

IRS offers you a full package of Formula One information, Grand prix 2
related sections as a Hot Lap competition.

Enjoy all the stuff and come to visit the International Racing Site
at http://www.kart.nl/irs.