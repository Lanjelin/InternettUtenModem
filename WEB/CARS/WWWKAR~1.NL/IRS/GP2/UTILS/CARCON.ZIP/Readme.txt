1. Copy carcon.bat into GP2\GAMEJAMS directory.

2. Make sure that the GP2JAM.EXE file*,
   and both the .BMP and .JAM files are in this same directory (GP2\GAMEJAMS).
   ie. gp2jam.exe
       Benetton.bmp    Benetton.jam
       Ferrari.bmp     Ferrari.jam
       etc.

3. Run carcon.bat file. This will automatically convert all 14 .bmp files to .jam files.
   This batch file is only for use with Trevor Kellaway's .BMP-.JAM Converter program.

* Found in Trevor Kellaway's .BMP-.JAM Converter program.

1996 � Gesualdo Carlotta