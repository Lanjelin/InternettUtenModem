
           ==== ORIGINAL NOTE FROM THE AUTHOR====
     Working on the file sample.cat in the sound directory,
     I found that it's made of 100 .wav files packed one 
     after the other, just with a small header before of
     each. So I wrote a program to extract those 100 files
     in standard .wav format. And I write another program to
     insert a .wav file in the sample.cat. In this way You
     will be able to listen all the sounds of the game, there
     are many that you never be able to listen at, e.g. the
     radio messages from the pits in many languages and 
     modify it for play with your own engine's sound. Well,
     now a brief explanation of how to run these two small
     programs.


     Extract
     The extract program is called extwav.exe . First copy
     the sample.cat file in a directory of your own, together
     with the extwav program. Then run it (no parameters are
     needed), in a while you will have 100 .wav files named 
     sound0.wav until sound99.wav.


     Inserting
     To insert a file use the inswav.exe program.
     Put this program in the directory with the sample.cat
     and the soundXX.wav files, al the files are needed form
     0 to 99. Start inswav, now, Your sample.cat is modified
     and ready to play by gp2 program as soon as you will put
     it in the sound directory. This version of the program
     can change the size of the sample.cat file. Take care to
     use the same kind of sound, 22/11 Khz mono 8 bit of the
     original sound.
             ------------------------------------
             Maracich Giorgio - esatb@mbox.vol.it
             ------------------------------------
