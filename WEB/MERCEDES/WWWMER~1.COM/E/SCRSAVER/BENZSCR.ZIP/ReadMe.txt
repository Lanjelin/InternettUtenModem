Installationshinweise
=======================================

Win 3.x
---------------------------------------
Kopieren Sie die .scr und die .avi Datei
in Ihr Windows-Verzeichnis.
Starten Sie die Systemsteuerung.
Tragen Sie unter 'Desktop' den Mercedes-Benz
Bildschirmschoner ein.


Win95
---------------------------------------
Kopieren Sie die .scr und die .avi Datei
in Ihr Windows-System-Verzeichnis.
Starten Sie die Systemsteuerung.
Tragen Sie unter 'Anzeige/Bildschirmschoner'
den Mercedes-Benz Bildschirmschoner ein.


Win NT
---------------------------------------
Kopieren Sie die .scr und die .avi Datei
in Ihr Windows-System32-Verzeichnis.
Starten Sie die Systemsteuerung.
Tragen Sie unter 'Anzeige/Bildschirmschoner'
den Mercedes-Benz Bildschirmschoner ein.



Probleme
=======================================

Netzwerk
---------------------------------------
Der Bildschirmschoner ist nicht Netzwerkf�hig.
D.h., bei einer Netzwerkinstallation von
Windows ist die Lauff�higkeit nicht gew�hrleistet.

Treiber
---------------------------------------
�berpr�fen Sie Ihre Treiberkonfiguration.
Starten Sie die .avi - Datei in der Medienwiedergabe
bzw. durch Doppelklick im Dateimanager/Explorer.
Wird das Video abgespielt, sind die ben�tigten
Treiber installiert. Pr�fen Sie, ob sich die Dateien im
richtigen Verzeichnis befinden. Beide Dateien m�ssen sich
im selben Verzeichnis befinden.
Kann das Video nicht wiedergegeben werden, ist auf
Ihrem System Video for Windows nicht installiert bzw.
der entsprechende Codec fehlt.
Installieren Sie VfW und den Indeo-Codec und testen Sie
erneut.
Die entsprechenden Treiber k�nnen Sie von unserem Server
�ber die Bildschirmschoner-Seite herunterladen.

