Zur Installation des Bildschirmschoners
beide Dateien (scr/dll) in das
Windows/System Verzeichnis (Win95) bzw.
in das WIndows Vz. (Win311) kopieren.
Dann in der Systemsteuerung/Desktop anmelden.

Frohe Weihnachten,
MfG
M. Volkland
MEX Multimedia
